// c99
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#ifndef MAX_SIZE
#error Error, NMAX is empty
#endif

// Получение времени в миллисекундах
unsigned long long milliseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000ULL + val.tv_usec / 1000ULL;
}

int main(void)
{
    int mas[MAX_SIZE];
    int n = sizeof(mas) / sizeof(mas[0]);
    long long unsigned beg, end;
    srand(time(NULL));
    int uniq_count = 0;
    for ( int i = 0 ; i < n; i++)
        mas[i] = rand();
    beg = milliseconds_now();            
    for (int i = 0; i < n; ++i) 
        if (*(mas + i) == 0)
            uniq_count = 1;
    for (int i = 0; i < n; ++i)
        for (int j = i+1; j < n; ++j)
            if (*(mas + i) == *(mas + j) && *(mas + i) != 0)
                *(mas + j) = 0;
    for (int i = 0; i < n; ++i)
        if (*(mas + i) != 0)
            uniq_count++;
    end = milliseconds_now();
    printf("%llu\n", end - beg);
    
    mas[0] = 123;
    mas[0] = 156;

    return EXIT_SUCCESS;
}

