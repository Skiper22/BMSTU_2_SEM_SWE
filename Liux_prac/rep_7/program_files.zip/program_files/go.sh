#!/bin/bash

./build_apps.sh
./update_data.sh
./make_preproc.sh
./make_postproc.sh

