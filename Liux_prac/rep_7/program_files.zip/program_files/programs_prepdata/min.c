#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int len = 0;
    double sum = 0.0;
    double buf = 0.0;
    double mymax = 0.0;
    double mymin = 0.0;
    if (scanf("%lf", &buf) == 1)
    {
        mymax = buf;
        mymin = buf;
        len++;
        sum += buf;
    }
    while (scanf("%lf", &buf) == 1)
    {
        len++;
        sum += buf;
        if (buf < mymin)
            mymin = buf;
        if (buf > mymax)
            mymax = buf;
    }
    printf("%.6lf ", mymin);
    
    return EXIT_SUCCESS;
}
