#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

double median(double a[MAX_SIZE], int , int);

int main() 
{ 
    double a[MAX_SIZE];
    int n = 0, i, t, j;
    double elem = 0;
    double Q1, Q2, Q3;

    if (scanf("%lf", &elem) == 1)
        a[n] = elem;
    n++;
    while (scanf("%lf", &elem) == 1)
        a[n++] = elem;  

    for (i = 0; i < n; i++) 
        for (j = 0; j < n; j++)     
            if(a[i] < a[j])
            {
                t = a[i];
                a[i] = a[j];
                a[j] = t; 
            }       
    Q1 = median(a, 0, n/2-1);   

    Q2 = median(a, 0, n-1);   
    if (n % 2 == 0)    
        Q3 = median(a, n/2, n-1);
   else
        Q3 = median(a, n/2+1, n-1);

    //printf("%.1f",Q1);//lower_quartil
    printf("%.1f", Q2);//meadian
    //printf("%.1f",Q3);//upper qwartil 
    
    return EXIT_SUCCESS;

} 

double median(double a[MAX_SIZE], int start, int end)
{
    double med;
    int len = end - start + 1;
    if( len % 2 == 0)
        med = ( (a[start + len/2 -1] + a[start+len/2] ) / 2.0);   
    else   
        med = ( a[start+len/2]/ 1.0);   

      return med;
}
