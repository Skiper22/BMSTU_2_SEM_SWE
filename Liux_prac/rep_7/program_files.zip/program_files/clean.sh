#!/bin/bash

cd post_data
rm ./*/*
cd ..
cd prepdata
rm ./*/*
cd ..
