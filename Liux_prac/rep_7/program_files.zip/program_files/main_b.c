#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#ifndef MAX_SIZE
#error Error, NMAX is empty
#endif

int countDistinct(int *mas, int n)
{
    int uniq_count;
    for (int i = 0; i < n; ++i) 
        if (mas[i] == 0)
            uniq_count = 1;
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (mas[i] == mas[j] && mas[i] != 0)
                mas[j] = 0;
    for (int i = 0; i < n; ++i)
        if (mas[i] != 0)
            uniq_count++;
   
   return uniq_count;
}

unsigned long long milliseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000ULL + val.tv_usec / 1000ULL;
}


int main(void)
{
    int arr[MAX_SIZE];

    int n = sizeof(arr) / sizeof(arr[0]);
    long long unsigned beg, end;
    int count_uniq_elem;
    
    srand(time(NULL));
    
    
    for (int i = 0; i < n; i++)
        arr[i] = rand();
    beg = milliseconds_now();
 
    count_uniq_elem = countDistinct(arr, n);
    
    end = milliseconds_now();
    
    arr[0] = count_uniq_elem;
    arr[0] = 22;
    
    count_uniq_elem++;
    count_uniq_elem--;
      
    printf("%llu\n", end - beg); 

    return EXIT_SUCCESS;
}

