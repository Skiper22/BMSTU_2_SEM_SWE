#!/bin/bash

files=$(ls ./data/)
#programs=$(ls ./programs_prepdata/)
p1="sr_znach.exe"
p2="min.exe"
p3="max.exe"
p4="median.exe"
p5="lower_quartile.exe"
p6="upper_quartile.exe"

start="5000"
step="5000"
end="100000"

sizes="1"
for s in $(seq "$start" "$step" "$end"); do
    sizes="$sizes $s"
done

for fi in $files; do
    for s in $sizes; do
        SUB=$s
        if [[ "$fi" == *_"$SUB"_* ]]; then
            echo "$s" > ./prepdata/array_sizes/"${fi}.txt"
        fi
    done
done

for fi in $files; do
    ./programs_prepdata/"$p1" < ./data/"${fi}" > ./prepdata/sr_ariph/"${fi}.txt"
    ./programs_prepdata/"$p2" < ./data/"${fi}" > ./prepdata/min/"${fi}.txt"
    ./programs_prepdata/"$p3" < ./data/"${fi}" > ./prepdata/max/"${fi}.txt"
    ./programs_prepdata/"$p4" < ./data/"${fi}" > ./prepdata/median/"${fi}.txt"
    ./programs_prepdata/"$p5" < ./data/"${fi}" > ./prepdata/low_quartile/"${fi}.txt"
    ./programs_prepdata/"$p6" < ./data/"${fi}" > ./prepdata/up_quartile/"${fi}.txt"
done

programs="a b c"
opts="Os O0 O1 O2 O3"

for p in $programs; do
    for s in $sizes; do
        for fi in $files; do
            for op in $opts; do
                if [[ "$fi" == "${p}"_"${s}"_"${op}"* ]]; then
                    p1=$(cat ./prepdata/array_sizes/"${p}"_"${s}"_"${op}"*)
                    p2=$(cat ./prepdata/sr_ariph/"${p}"_"${s}"_"${op}"*)
                    echo "$p1 $p2" >> ./post_data/graphic1/"${p}_${op}".txt
                fi
            done
            
            if [[ "$fi" == "${p}_${s}_O2"* ]]; then
                p1=$(cat ./prepdata/array_sizes/"${p}_${s}_O2"*)
                p2=$(cat ./prepdata/max/"${p}_${s}_O2"*)
                p3=$(cat ./prepdata/min/"${p}_${s}_O2"*)
                p4=$(cat ./prepdata/sr_ariph/"${p}_${s}_O2"*)
                echo "$p1 $p4 $p2 $p3" >> ./post_data/graphic2/"${p}_O2.txt"
            fi
         done
     done
done
for s in $sizes; do
    for fi in $files; do
        if [[ "$fi" == "a_${s}_O3"* ]]; then
            p1=$(cat ./prepdata/array_sizes/"a_${s}_O3"*)
            p2=$(cat ./prepdata/sr_ariph/"a_${s}_O3"*)
            p7=$(cat ./prepdata/max/"a_${s}_O3"*)
            p3=$(cat ./prepdata/min/"a_${s}_O3"*)
            p4=$(cat ./prepdata/up_quartile/"a_${s}_O3"*)
            p5=$(cat ./prepdata/low_quartile/"a_${s}_O3"*)
            p6=$(cat ./prepdata/median/"a_${s}_O3"*)
            echo "$p1 $p2 $p6 $p3 $p7 $p5 $p4" >> ./post_data/graphic3/"a_O3.txt"
        fi
    done
done
   
