#!/bin/bash

gnuplot -persist paint_line_graph.gpi
gnuplot -persist paint_error_graph.gpi
gnuplot -persist paint_moustache.gpi
