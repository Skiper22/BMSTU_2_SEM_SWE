#!/bin/bash

opts="Os O0 O1 O2 O3"
step=5000
start=0
end=100000

for opt in $opts; do
    for size in $(seq "$start" "$step" "$end"); do
        if [ "$size" == "0" ]; then
            size=1
        fi
        gcc -std=c99 -Wall -Werror -Wpedantic -Wvla -Wextra -DMAX_SIZE="$size" -"${opt}" \
        main_a.c -o ./apps/app_a_"${size}"_"${opt}".exe
        gcc -std=c99 -Wall -Werror -Wpedantic -Wvla -Wextra -DMAX_SIZE="$size" -"${opt}" \
        main_b.c -o ./apps/app_b_"${size}"_"${opt}".exe
        gcc -std=c99 -Wall -Werror -Wpedantic -Wvla -Wextra -DMAX_SIZE="$size" -"${opt}" \
        main_b.c -o ./apps/app_c_"${size}"_"${opt}".exe
    done
done 
