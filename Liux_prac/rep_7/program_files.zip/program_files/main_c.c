#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#ifndef MAX_SIZE
#error Error, NMAX is empty
#endif

int find_count_uniq_elements(int *pa, int *pb)
{
    int result = 0;
    for (; pa < pb; pa++)
    {
        int flag = 0;
        for (int *pa1 = pa; pa1 < pb; pa1++)
        {
            if (*pa == *pa1)
                flag++;
        }
        if (flag == 1)
            result++;
    }

    return result;
}

unsigned long long milliseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000ULL + val.tv_usec / 1000ULL;
}


int main(void)
{
    int arr[MAX_SIZE];
    int array_size = sizeof(arr) / sizeof(arr[0]);
    long long unsigned beg, end;
    
    int *pa = arr, *pb;
    pb = pa + array_size;
    srand(time(NULL));    
    
    for (int i = 0; i < array_size; i++)
        arr[i] = rand();
    beg = milliseconds_now();
    int uniq = find_count_uniq_elements(pa, pb);
    end = milliseconds_now();
    
    arr[0] = uniq;
    uniq +=1;
    uniq -=1;
          
    printf("%llu\n", end - beg); 

    return EXIT_SUCCESS;
}

