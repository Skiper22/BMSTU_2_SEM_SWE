#!/bin/bash

gnuplot -persist paint_line_graph.gpi
