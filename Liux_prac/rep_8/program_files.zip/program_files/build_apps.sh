#!/bin/bash

opts="Os O0 O1 O2 O3"
step=50
start=50
end=800

for opt in $opts; do
    for size in $(seq "$start" "$step" "$end"); do
        gcc -std=c99 -Wall -Werror -Wpedantic -Wvla -Wextra -DMAX_SIZE="$size" -"${opt}" \
        main_a.c -o ./apps/app_a_"${size}"_"${opt}".exe
        gcc -std=c99 -Wall -Werror -Wpedantic -Wvla -Wextra -DMAX_SIZE="$size" -"${opt}" \
        main_b.c -o ./apps/app_b_"${size}"_"${opt}".exe
    done
done 
