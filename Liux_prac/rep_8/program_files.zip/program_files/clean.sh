#!/bin/bash

cd post_data
rm ./*/*
cd ..
cd prepdata
rm ./*/*
cd ..
cd data
rm *
cd ..
cd apps
rm *
cd ..
