#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

#ifndef MAX_SIZE
#error Error, NMAX is empty
#endif

unsigned long long milliseconds_now(void);
void init_matrix(int (*matrix)[MAX_SIZE]);
void sum_matrix(int (*matrix_a)[MAX_SIZE], int (*matrix_b)[MAX_SIZE], int (*matrix_c)[MAX_SIZE], int k);
void print_matrix(int (*matrix)[MAX_SIZE]);

int main(void)
{    
        
    int a[MAX_SIZE][MAX_SIZE];
    int b[MAX_SIZE][MAX_SIZE];
    int c[MAX_SIZE][MAX_SIZE];

    init_matrix(a);
    init_matrix(b);
    
    srand(time(NULL));
    int coefficient_a = rand() % 10;
    
    long long unsigned beg, end;
    
    beg = milliseconds_now(); 
       
    sum_matrix(a, b, c, coefficient_a);
    
    end = milliseconds_now();  
    
    c[0][0] = c[0][1];
    c[0][1] = c[1][1];
    
    a[0][0] = a[0][1];
    a[0][1] = a[1][1];
    
    b[0][0] = b[0][1];
    b[0][1] = b[1][1];
    
    printf("%llu\n", end - beg);
    
    return EXIT_SUCCESS; 
}

// Получение времени в миллисекундах
unsigned long long milliseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) - 1;

    return val.tv_sec * 1000ULL + val.tv_usec / 1000ULL;
}

void init_matrix(int (*matrix)[MAX_SIZE])
{
    for (size_t i = 0; i < MAX_SIZE; i++)
        for (size_t j = 0; j < MAX_SIZE; j++)
            matrix[i][j] = j + i;
}

void sum_matrix(int (*matrix_a)[MAX_SIZE], int (*matrix_b)[MAX_SIZE], int (*matrix_c)[MAX_SIZE], int k)
{
    for (size_t i = 0; i < MAX_SIZE; i++)
        for (size_t j = 0; j < MAX_SIZE; j++)
            matrix_c[i][j] = k * matrix_a[i][j] + matrix_b[i][j];
}

void print_matrix(int (*matrix)[MAX_SIZE])
{
    for (size_t i = 0; i < MAX_SIZE; i++)
    {
        for (size_t j = 0; j < MAX_SIZE; j++)
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
}

