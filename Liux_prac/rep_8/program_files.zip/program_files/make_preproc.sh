#!/bin/bash

files=$(ls ./data/)
#programs=$(ls ./programs_prepdata/)
p1="sr_znach.exe"

start="50"
step="50"
end="800"

sizes=""
for s in $(seq "$start" "$step" "$end"); do
    sizes="$sizes $s"
done

for fi in $files; do
    for s in $sizes; do
        SUB=$s
        if [[ "$fi" == *_"$SUB"_* ]]; then
            echo "$s" > ./prepdata/array_sizes/"${fi}.txt"
        fi
    done
done

for fi in $files; do
    ./programs_prepdata/"$p1" < ./data/"${fi}" > ./prepdata/sr_ariph/"${fi}.txt"
done

programs="a b"
opts="Os O0 O1 O2 O3"

for p in $programs; do
    for s in $sizes; do
        for fi in $files; do
            for op in $opts; do
                if [[ "$fi" == "${p}"_"${s}"_"${op}"* ]]; then
                    p1=$(cat ./prepdata/array_sizes/"${p}"_"${s}"_"${op}"*)
                    p2=$(cat ./prepdata/sr_ariph/"${p}"_"${s}"_"${op}"*)
                    echo "$p1 $p2" >> ./post_data/graphic/"${p}_${op}".txt
                fi
            done
        done
    done
done
