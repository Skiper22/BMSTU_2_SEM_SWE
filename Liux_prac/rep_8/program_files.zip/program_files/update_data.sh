#!/bin/bash

count=1000
opts="Os O0 O1 O2 O3"
sizes=""
letter="a b"
start="50"
step="50"
end="800"

sizes=""
for size in $(seq "$start" "$step" "$end"); do
    sizes="$sizes $size"
done 

if [ -n "$1" ]; then
    program_name=$1
fi

if [[ "$program_name" == *"_a"* ]]; then
  letter="a"
fi

if [[ "$program_name" == *"_b"* ]]; then
  letter="b"
fi

if [ -n "$2" ]; then
    sizes=$2
fi
if [ -n "$3" ]; then
    opts=$3
fi
if [ -n "$4" ]; then
    count=$4
fi

for l in $letter; do
    for s in $sizes; do
        for op in $opts; do
            for k in $(seq "$count"); do
                echo -n -e "app_${l} | $k/$count $op $s \r"
                ./apps/app_"${l}"_"${s}"_"${op}".exe >> ./data/"${l}"_"${s}"_"${op}".txt
            done
        done
    done
done 
echo $'\n'
